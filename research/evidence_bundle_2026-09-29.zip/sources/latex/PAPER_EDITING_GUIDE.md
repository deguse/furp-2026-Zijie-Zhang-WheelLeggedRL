> **2026-09-29 closeout override (user-approved plan):** The current deliverable is a system-engineering FURP report and A0 poster. No new experiments or training are scheduled. Explicitly labeled single-seed E6/A1 values may appear in the report and poster; they are not aggregates. The active implementation snapshot is p2-classical-upper-bound at d1d12e4 plus preserved uncommitted changes, not the old hybrid-v2 location. Use the updated evidence_matrix.md and verified_numbers.tex. Historical deadlines, pending C2/C3/hardware promises, old C1 summary numbers, and rules requiring E7 before the present closeout are superseded. The unchanged original guide is in the closeout backup.

# HopperTrex IEEE 论文维护指南

> **2026-07-27 更新（Claude）**：`main.tex` 已按 `D:\mjlab_workspace\to-do.md` §11
> 收束标准重构为"先资格化经典栈、后有界残差"的双战役结构
> （planar/recovery 战役 + stair C0–C* 战役），标题与章节随之更新。
> 单种子 formal 数字（E6 +12.4%、A1 腿归因 ≈2/3、E3 +2.8% 证伪、
> A4 ≤40 ms 部署门、C0 死亡高度 0.01 m、C1 全门 15/15）按"显式标注
> single-seed/probe"的新 claim gate 入文（见 `evidence_matrix.md` 同日更新）；
> C2/C3/C*、楼梯残差裁决与硬件仍为 TBD。新增 `poster.tex`
> （tikzposter A0 横版），与论文同源同纪律。本指南以下章节的 Stage 语义
> 与规则仍适用于 planar/recovery 部分；stair 部分注册规则以实验仓
> mainline doc 为准。旧版论文备份于 `tmp/main_hybridv3_backup_20260727.tex`。

这份指南对应当前 Hybrid v3 论文与实验路线。实现事实以
`D:\mjlab_workspace\furp-2026-Zijie-Zhang-WheelLeggedRL\.worktrees\hybrid-v2`
为准；论文工作区仍为 `D:\Latex`。实验仓库中的当前实现版本可以
帮助核对代码，但任何历史证据必须保留其实际产出 commit，不能统一
改绑到最新 HEAD。

当前论文题目：

> Hybrid Residual Reinforcement Learning for Stable Control of a Two-Wheeled Legged Robot

## 1. 工作区与事实来源

| 文件或目录 | 作用 |
| --- | --- |
| `main.tex` | 论文正文、公式、表格和内嵌架构图 |
| `references.bib` | BibTeX 文献库 |
| `evidence_matrix.md` | 实验状态、证据边界和结果回填入口 |
| `PAPER_EDITING_GUIDE.md` | 本维护流程 |
| `figures/` | 正式轨迹、消融图和硬件照片 |
| `build/` | LaTeX 临时产物 |
| `output/pdf/` | 确认后的稳定 PDF |

论文内容按以下路径更新：

```text
实验 gate / probe / artifact
  -> experiment_log.md 核对事实
  -> evidence_matrix.md 记录证据等级和来源
  -> main.tex 更新方法、表格、图和结论
  -> 编译并逐页检查 PDF
```

不要直接从终端日志、截图或周报复制性能数字。正式数字必须可以追溯
到 source Git SHA、artifact hash、checkpoint、gate JSON/CSV、seed 和
评估 profile。

## 2. 当前方法事实

### 2.1 经典层

论文统一使用 **identified LQR**。该命名已有系统辨识、秩与 held-out
误差资格化以及 gain hash 支持，不再沿用旧稿的 PD 占位表述。

“Classical stack” 指完整零残差基线，不只是 LQR：

1. identified LQR balance/longitudinal feedback；
2. longitudinal velocity calibration；
3. yaw feedforward calibration；
4. posture-dependent station-keeping compensation；
5. height/pitch-to-joint posture map；
6. rate-limited posture reference shaping；
7. actuator clipping and wheel-target slew limiting。

若实现增加滤波、延迟补偿或新的 artifact，必须同时更新公式、架构图、
部署描述和 provenance 字段。

### 2.2 六维残差接口

固定 action contract 为：

```latex
a_t = [r_{bal}, r_{yaw}, r_{L,thigh}, r_{R,thigh},
       r_{L,knee}, r_{R,knee}]^\top.
```

经 mask 与 scale 后，左右轮残差映射为：

```text
left wheel  = -r_bal + r_yaw
right wheel =  r_bal + r_yaw
```

四个腿通道加到 posture map 的名义关节目标。修改实现时必须核对维度、
顺序、符号、scale、mask、clip 和 slew limit；不能只检查网络输出维度。

### 2.3 Qualification-before-learning

每个扩大后的 command envelope 先用零残差经典栈做物理资格化：

- 可重复、单调、可标定的名义效应归经典层；
- PPO 只承担模型误差、瞬态和大扰动恢复余量；
- gate 阈值必须高于实测物理底噪并注明来源；
- 改善声明必须使用 matched zero-residual baseline、预注册主指标和最低
  事件数；
- 新 checkpoint 必须通过旧能力 retention gate。

## 3. 当前 Stage 语义

| Stage | 当前含义 | Active residuals |
| --- | --- | --- |
| 0 | LQR identification 与纵向标定资格化 | none |
| 1 | 固定腿纵向瞬态和轻扰动 | balance |
| 2 | yaw 前馈资格化与平面轮残差价值检验 | balance, yaw |
| 3 | posture map、station compensation、reference shaping | all six |
| 4 | 跨姿态 planar integration 资格化 | all six |
| 5 | 大扰动下全六维 residual recovery | all six |

当前路线中 Stage 3/4 是经典层资格化和 checkpoint migration carrier，
没有独立 PPO training campaign。不能把它们写成“Stage 3 policy/Stage 4
policy 已取得性能提升”。主要 residual value comparison 位于 Stage 5。

## 4. Baseline 与消融规则

论文主比较固定为：

1. **Classical stack**：完整经典层，六维 residual 全部清零；
2. **Hybrid residual**：同一经典层加 bounded PPO residual。

主要 attribution ablation 为：保持同一训练 checkpoint 和轮 residual，
只在评估时 mask 四个 leg residual。它用于判断腿通道贡献，不是单独训练
的方法。

辅助 stress tests：

- bounded training-duration probe；
- disturbance-amplitude curve；
- delay and sensor-noise tolerance matrix（已完成单种子 probe，只用于部署
  准入边界，不作为 aggregate 性能证据）。

PPO-only 可以作为历史背景或未来补充，但不再是当前 headline table 的
必需 baseline。不得悄悄改变两种主配置的 command、horizon、disturbance、
limits、seed 或 evaluation profile。

## 5. 证据等级与实验编号

状态词：

```text
planned -> probe -> formal -> aggregate -> hardware
```

- `probe`：诊断或 stress test，不用于 headline claim；
- `formal`：该 seed 的预注册评估完整；通过或失败都可以是 formal；
- `aggregate`：seeds 1/2/3 完整，并报告 mean、standard deviation、failure rate；
- `hardware`：带部署与安全元数据的实机证据。

当前编号：

| ID | 含义 |
| --- | --- |
| E0 | identified LQR 与纵向 calibration |
| E1 | 三种子 classical longitudinal qualification |
| E2 | yaw/planar classical qualification |
| E3 | planar wheel-residual value falsification |
| E4 | posture/station/reference qualification |
| E5 | cross-posture planar integration qualification |
| E6 | single-seed Stage5 classical-vs-hybrid comparison |
| E7 | Stage5 multi-seed reproduction |
| A1 | leg residual attribution |
| A2 | training-duration probe |
| A3 | disturbance-amplitude curve |
| A4 | delay/noise tolerance matrix（single-seed probe complete） |
| P1.1 | static-to-dynamic posture-envelope qualification |
| H1 | guarded hardware validation |

E3 是完整的正式负结果，不应写成“实验尚未完成”；但也不能写成 hybrid
在平面任务上优于 classical。E6/A1 是单 seed formal，当前不进入摘要、
结论和 headline 数字。A4 只能用于组织部署准入框架；P1.1 只能用于说明
“静态筛选--动态探测--补偿资格化”的方法。只有 E7 成为 aggregate 后，
才回填主要 residual 性能结果。

## 6. 各章节维护规则

### Abstract 与 Conclusion

当前阶段应明确：

- implemented method 已与代码同步；
- formal multi-seed residual aggregates 尚未完成；
- hardware validation 尚未完成。

禁止把单 seed Stage5、部署代码或 runbook 写成 aggregate improvement 或
sim-to-real success。E7 完成后，可使用：

```text
Across three seeds, the hybrid residual controller [VERIFIED RESULT] relative
to the matched zero-residual classical stack under [EVALUATION SCOPE].
```

### Introduction 与 Contributions

贡献应围绕：

1. complete classical stack + bounded residual architecture；
2. fixed six-dimensional residual contract；
3. qualification-before-learning、retention 与 attribution protocol。

不要把使用 PPO、MuJoCo 或 Python 本身写成贡献。

### Method

核心公式为：

```latex
u_t^{cl} = \pi_{cl}(x_t,c_t,p_t^\star;\theta_{LQR},\Gamma),
u_t = \mathcal{S}(u_t^{cl} + B M_k D a_t).
```

其中 `Gamma` 必须覆盖 longitudinal、yaw、station 和 posture artifacts。
零 residual baseline 是 `u_t^{cl}` 全栈。任何正文把 posture mapping 写在
经典栈外、或把 yaw nominal tracking 写成 PPO 职责，都属于实现漂移。

### Experimental Protocol

每个正式比较至少锁定：

- source revision 与 clean-tree 状态；
- controller/calibration/posture/station hashes；
- checkpoint SHA-256；
- command/disturbance 与事件数；
- profile、horizon、environment count、seed；
- contact semantics、retention 与 viewer verdict。

Screen 只用于拒绝和筛选，不能作为 improvement evidence。正式事件型
改善必须满足预注册 minimum event count。

### Results 与 Failure Attribution

正式结果表只填 aggregate。单 seed 可用于机制讨论，但必须标为
single-seed diagnostic/formal evidence，且不能出现在摘要数字中。

当前允许定性讨论的机制：

- velocity bias 应由 calibration 修正；
- 大而恒定的 yaw residual 表明 channel misallocation；
- posture-dependent drift 应由 station compensation 修正；
- step posture reference 需要 shaping；
- longer training 可能造成 retention regression；
- gate threshold 低于 measured floor 属于 protocol defect；
- non-wheel contact 不能算 upright success。

## 7. 图表与结果回填

正式主图建议使用 paired recovery trajectory，统一时间轴展示：

1. classical 与 hybrid 的 recovery state；
2. pitch / pitch rate；
3. wheel residual；
4. leg residual；
5. contact、clipping 或 slew saturation event。

图必须从 gate JSON/CSV 直接导出，不得根据 viewer 截图手绘。单栏图使用
`figure` 和 `\columnwidth`；表格标题在上，图片标题在下。颜色不能是唯一
编码，应同时使用线型或 marker。

回填顺序：

1. 完成 E7 seeds 1/2/3；
2. 在 evidence matrix 中填写各 seed provenance；
3. 计算预先定义的 aggregate；
4. 回填主结果表与 attribution table；
5. 生成 paired trajectory 和 aggregate figure；
6. 最后同步 Abstract、Results 正文与 Conclusion。

若一个 seed 失败，必须纳入 failure rate；不能只对成功 seed 求平均。

## 8. 编译与视觉检查

PowerShell：

```powershell
cd D:\Latex
latexmk -pdf -interaction=nonstopmode -halt-on-error -outdir=build main.tex
Copy-Item -LiteralPath .\build\main.pdf `
  -Destination .\output\pdf\hoppertrex_hybrid_residual_draft.pdf -Force
```

引用或辅助文件异常时：

```powershell
latexmk -C -outdir=build main.tex
latexmk -pdf -interaction=nonstopmode -halt-on-error -outdir=build main.tex
```

每次有意义修改后必须检查：

- 无 undefined citation/reference；
- 无 overfull box、文字重叠、裁切和不可读图表；
- caption 与当前数据一致；
- 表格精度和单位一致；
- Abstract、Results、Conclusion 使用相同 aggregate；
- 最后一页参考文献和页数满足目标 venue。

## 9. BibTeX 维护

新增文献时核验正式标题、作者、venue、年份、页码和 DOI。引用键使用
`authorYearKeyword` 风格。GitHub README 可以帮助发现关键词，但不能
替代应引用的正式论文。新增后运行完整 `latexmk`，不要只运行一次
`pdflatex`。

## 10. 实机边界

当前 portable classical stack、policy export、HAL mock、安全状态机和
50 Hz loop 都属于准备工作。只有 H1 实际完成后，才能把章节从
`Planned Hardware Validation` 改为 `Hardware Validation`。

实机记录至少包括：控制/通信频率、IMU 与编码器来源、odometry、action
mapping、delay/filter、wheel/leg limits、artifact hashes、watchdog、e-stop、
人工干预、失败和 session log。结论不得超过实际测试速度、扰动和地面
条件。

## 11. 当前优先级

1. 完成 E7 Stage5 seeds 2/3，并按预注册规则生成三种子 aggregate；
2. 在 frozen short-training candidate 上完成最终 attribution 与必要曲线；
3. 保持 A4 latency/noise 与 P1.1 posture qualification 为框架/边界证据，
   不提升为 headline result；
4. 导出正式主表、paired recovery trajectory 和消融图；
5. 同步摘要、结果与结论中的 aggregate 数字；
6. 硬件可用后按 R0--R3 runbook 推进 H1。

最重要的维护原则是：先保留可追溯证据，再写结果；先资格化经典层，
再判断 residual 是否真的增加价值。
