# Public evidence subset

Exported on 2026-10-03 from the immutable 2026-09-29 closeout; narrowed to code and evidence on 2026-10-04. Historical paths and Git SHAs inside records identify original experiments, not install paths.

Includes core records, two checkpoints, 16 frozen diagnostic source files, runtime metadata and the standard-library metric extractor. The complete current source is in the repository. `metadata/evidence_matrix.md` explains the supported claims and version boundaries. Reports, posters, presentation scripts and generated figures are excluded.

Original evidence, checkpoint, source-manifest and frozen code bytes are unchanged. The extractor retains the JSON/CSV computations but no longer produces presentation-only LaTeX. The original local closeout remains unchanged. This is not a new physics experiment or hardware qualification.
