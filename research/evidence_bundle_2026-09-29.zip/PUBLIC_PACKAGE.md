# Public evidence subset

Exported on 2026-10-03 from the immutable 2026-09-29 closeout. Historical paths and Git SHAs inside records identify original experiments; they are not install paths. Includes only the 16 frozen code files required to verify the diagnostic causal manifest; the complete current source is in the repository. This is not a new physics experiment or a hardware qualification.
