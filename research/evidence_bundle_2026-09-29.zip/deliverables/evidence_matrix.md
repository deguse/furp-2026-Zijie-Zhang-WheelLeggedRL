# HopperTrex Closeout Evidence Matrix

Updated 2026-09-29. This matrix supersedes unfinished-work placeholders in the July draft. Historical versions are preserved in the closeout backup.

## Claim levels

- Implementation: source and focused software checks; not hardware validation.
- Formal: an identified experiment under its registered protocol; can be a valid negative and need not be multi-seed.
- Training progress: a stored curriculum/checkpoint state, not final capability adjudication.
- Development diagnostic: explanation/rejection only, never silent promotion.
- Uncompleted: reported as a limitation or future work, not promised for this closeout.

## Results admitted to the report and poster

| ID | Evidence and scope | Admitted conclusion | Excluded interpretation |
|---|---|---|---|
| E6 | Stage5, seed 1, formal, 128 events per arm; source 2fb98ee | 1.01296875 s -> 0.8871875 s; 12.41709% improvement; zero event termination/contact | No cross-seed generalization; events are not training seeds |
| A1 | Same checkpoint, leg channels masked, own matched baseline | 0.99765625 s -> 0.95953125 s; 3.82146% improvement | Not an exact two-thirds causal contribution estimate |
| Retention | Separate Stage1 formal record, 69 checks | 68 checks pass; the separate improvement requirement fails | Do not describe E6 as every gate passing |
| C1 | Later affine schedule; 15 registered flat-control cells | Flat qualification passes, zero terminations/non-wheel contacts | Not evidence of stair capability, and not the E6 controller version |
| C2-j3 | Formal qualification, 125 candidates / 288 pairs | No qualified candidate; zero timely detections for all candidates | Not a universal impossibility claim for contact detection |
| SC | Seed-1 progress after 1,000 updates / 20 evaluations | Upper curriculum height remains 0.01 m at the checkpoint | Not completed final selection, evaluation or multi-seed adjudication |
| R0 | Formal seed 1, 480 trials, two posture cards | Flat 96/96; 2.5 mm 18/96 with 73 unsupported trials; training forbidden | Combined display counts do not replace per-card 44/48 and zero-safety gates |
| R0c | Dirty HEAD d1d12e4 plus 16 verified causal-file hashes | Latest effort sanity rejected; both tested backends pass flat and safely stall at 2.5 mm | No formal actuator/backend promotion; no unique wheel-loop cause established |

## Source files and SHA256

Archive paths below are relative to closeout_2026-09-29. Full original paths are in metadata/source_manifest.json.

| ID | Archive path | SHA256 |
|---|---|---|
| E6 | evidence/stage5/seed1_stage5_robust_formal.json | 8a0e9db2a1bfd150c268514c902f38b77e2c14209783fbe55ae7c0dcd1bb04af |
| A1 | evidence/stage5/seed1_stage5_robust_formal_legs_ablated.json | 12798a1a703a1c132a8c952f70a22d082ed57de7dc9ced17438568d6b9012338 |
| Retention | evidence/stage5/seed1_stage1_retention_formal.json | 52cfbfbe03ecc01c7f0f94de37fe4e4c2c69131ec8505646d84bcc83f8276d41 |
| C1 | evidence/c1_original/c1_affine_full_gate.json | 12496025d32210156d5d1b53a5796fe8a746dedb890bf4a77f2540dc35dd4cb5 |
| C2-j3 | evidence/c2/qualification.json | 9dead0498402fdbf8fd5d1446702269083558cbe85919091bce4c192296be7a3 |
| SC | evidence/camp/model_999.progress.json | 104420e5efe733ab0a4b9fde972c2fd2f14cb0c52b369777d74948e6124ccd2e |
| R0 | evidence/r0/roll_boundary.json | dbbd777dd718b8c31e8f7b3ea68d702592f5a742efa03e25c216c75addee881b |
| R0c | evidence/r0c/r0c_effort_wbc_sanity_finalreview_dev.json | ee5bbcb5f9e301d09763602d2fbcafbd56fae0caf99047a53aec6b9caad2838b |

## C1 numerical correction

The original gate, selection file and SHA256SUMS agree with each other. Previous prose, including the July manuscript, contained different summary numbers. The reason for that prose drift is not inferred here. The source data is not edited.

| Metric | Earlier prose | Verified gate |
|---|---:|---:|
| Worst velocity error (m/s) | 0.00406 (rounded 0.0041) | 0.007539507746696469 |
| Max cell p95 absolute pitch error (rad) | 0.01770 | 0.01581142283976078 |
| Max cell p99 absolute pitch rate (rad/s) | 0.24428 | 0.18520483374595642 |

The 15-cell passing conclusion is unchanged. Both the gate SHA256 (12496025...dd4cb5) and selection SHA256 (9f93cf28...228e1) are preserved.

## Version and interface boundaries

- E6/A1 use their historical fixed identified stack; C1/R0 use later schedules. Do not substitute one baseline for the other.
- Stage5 recovery enables wheel and leg residuals. R0 has zero residuals. Proposed RollAssist has leg-only residual authority but was not authorized by R0. StairCamp is a separate route.
- Strict R0 support is monitored at 5 ms from settling through success. Later success cannot erase an earlier unsupported substep.
- Same-state native replay is not native full-rollout qualification. A collision proxy creates a changed physical contract.
- Effort codecs, mocks and safety interfaces are implementation, not USB-CAN transport or hardware results.

## Closeout verification

- scripts/extract_metrics.py validates archived hashes, ratios, identities and raw-trial counts without simulation.
- 45 focused software tests and six subtests passed; no claim of a full-suite rerun.
- Stage5 checkpoint SHA256: 48a053f0d1acaa799b105c20bce29d5f4a738da36fd9117d4bdf5f03f2c63937.
- No new training, physics rollout, seed campaign or hardware trial was performed during closeout.
- Missing time-series are not synthesized; summary plots have no invented error bars.

## Uncompleted work

Independent-seed recovery reproduction, reliable stair climbing, wheel-inner-loop isolation, calibrated hardware transport and real closed-loop validation remain future work.
