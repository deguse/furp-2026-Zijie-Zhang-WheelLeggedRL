# Three-minute Showcase notes

**Title:** Engineering a Traceable Hybrid Controller for a Two-Wheeled Legged Robot

## English talk (about three minutes; rehearse at your own speaking pace)

### 0:00-0:25 | What problem did I work on?
My project is about HopperTrex, a robot with two wheels and four actuated leg joints. The wheels must balance the body, follow motion commands and reject disturbances. Moving the legs changes those balance dynamics. My goal was to build a control system where these responsibilities are explicit and where performance claims can be checked against recorded evidence.

### 0:25-1:10 | What did I build?
The left panel shows the architecture. A classical controller provides the nominal motion using identified feedback and calibrated references. A reinforcement-learning policy adds bounded corrections through a fixed six-dimensional interface. Masks determine which channels are allowed to act, and limits constrain the resulting commands. Around this, I integrated task configuration, checkpoint migration, evaluation tools and portable control interfaces. The contribution is this working system and its verification process, rather than inventing PPO or MuJoCo.

### 1:10-1:50 | How was it verified?
The middle panel shows the evidence chain. We first measure the operating envelope, then freeze the controller and protocol. A short screen can reject a candidate, but only the formal comparison supports a performance claim. Each record binds the code revision, calibration artifacts and checkpoint. This distinction matters: a program finishing successfully does not mean the robot passed its capability test. Hardware interfaces and software tests are also kept separate from actual hardware validation.

### 1:50-2:35 | What did the experiments establish?
The right panel gives two examples. In one formally evaluated training seed, the residual policy reduced recovery time from about 1.013 seconds to 0.887 seconds, an improvement of 12.42 percent. Masking the leg channels reduced the relative gain to 3.82 percent against its own matched baseline. That supports the importance of leg corrections in this experiment, but not an exact contribution percentage or a multi-seed claim. A later stair test passed all 96 flat trials, yet achieved only 18 successes out of 96 at 2.5 millimetres and failed the strict support requirement.

### 2:35-3:00 | What is the takeaway?
The project delivers a working hybrid-control stack, reusable engineering interfaces and a traceable evaluation process. It also identifies where the tested system is not ready: reliable stair climbing and physical deployment have not been demonstrated. My role covered integration, experiment design, diagnosis and evidence review, with collaborative and AI-assisted implementation. The results are simulation-only, and the recovery result is explicitly single-seed.

## 中文提词

- 左栏：轮子共享平衡、跟踪和恢复任务；腿改变工作点；经典层给名义控制，残差权限明确。
- 中栏：实现完成、程序跑完、正式资格通过是三回事；版本和哈希服务于追溯，不等于安全证明。
- 右栏：12.42% 是指定扰动场景、单 seed；消融用自己的成对基线，不说“精确贡献约三分之二”。
- 结尾：交付的是系统与可核查实验结果，不能说已可靠爬梯或完成实机验证。

## Likely questions

**Is 128 the number of training seeds?** No. It is the number of disturbance events per comparison arm. The reported policy has one training seed.

**Why not just train longer or relax the contact rule?** That would be a new experiment or a different protocol. The closeout preserves the existing decisions instead of changing the target after seeing the result.

**Did the robot ever traverse the step?** Yes: 18/96 trials at 2.5 mm succeeded. However, neither posture card satisfied its required success count with zero safety events; occasional traversal is not safe capability.

**Does the deployment code mean the hardware works?** No. It includes abstractions, mocks, safety logic and payload codecs. Transport, calibration and real closed-loop validation remain unfinished.

**What would you do next?** Register a narrow follow-up: independent-seed replication, an isolated wheel-inner-loop comparison, or guarded hardware bring-up. None was run for this closeout.
